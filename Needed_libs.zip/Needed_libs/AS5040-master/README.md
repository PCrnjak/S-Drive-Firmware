AS5040
======

Mark's AS5040 library for Arduino
