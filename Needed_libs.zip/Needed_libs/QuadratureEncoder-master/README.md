# QuadratureEncoder

Modified version of Cheng Saeterns QuadratureEncoder library Original library can be found here: https://github.com/Saeterncj/QuadratureEncoder All credit goes to him.

You can use this libary with stm32 boards and other arm boards supported by Arduino_STM32-master. You can use more than 2 encoders. You can only use hardware Interrupts. So on uno you can attach only one encoder since it takes 2 interrupt pins per encoder.
